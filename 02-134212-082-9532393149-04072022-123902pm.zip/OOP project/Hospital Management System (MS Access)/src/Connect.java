import java.awt.HeadlessException;
import java.sql.*;
import javax.swing.*;
public class Connect {
     
        static Connection con=null;
   
        public static Connection ConnectDB(){
//             String dataSourceName="HMS_DB";
//          String dbURL = "jdbc:odbc:" + dataSourceName;
        try{
            
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\DELL\\Desktop\\Hospital Management System (MS Access)\\HMS_DB.accdb"); 
            
            
        }catch(HeadlessException | ClassNotFoundException | SQLException e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
        return con;
}
}